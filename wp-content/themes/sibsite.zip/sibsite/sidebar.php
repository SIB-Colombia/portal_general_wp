<aside class="col-md-4 sidebar">
  <?php dynamic_sidebar('sidebar'); ?>
</aside>