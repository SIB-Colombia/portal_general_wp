<?php

get_header();

?>
<div class="section">
  <div class="container"></div></div>
<?php
get_footer();
?>